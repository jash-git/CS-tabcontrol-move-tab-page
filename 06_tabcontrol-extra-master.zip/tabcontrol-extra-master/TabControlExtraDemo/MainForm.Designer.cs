﻿/*
 * Created by SharpDevelop.
 * User: mjackson
 * Date: 28/06/2010
 * Time: 13:38
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace CSCustomTabControlDemo
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControlExtra7 = new System.Windows.Forms.TabControlExtra();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.tabPage45 = new System.Windows.Forms.TabPage();
            this.tabPage46 = new System.Windows.Forms.TabPage();
            this.tabPage47 = new System.Windows.Forms.TabPage();
            this.tabPage48 = new System.Windows.Forms.TabPage();
            this.tabControlExtra9 = new System.Windows.Forms.TabControlExtra();
            this.tabPage69 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabPage70 = new System.Windows.Forms.TabPage();
            this.tabPage71 = new System.Windows.Forms.TabPage();
            this.tabPage72 = new System.Windows.Forms.TabPage();
            this.tabPage73 = new System.Windows.Forms.TabPage();
            this.tabPage74 = new System.Windows.Forms.TabPage();
            this.tabPage75 = new System.Windows.Forms.TabPage();
            this.tabPage76 = new System.Windows.Forms.TabPage();
            this.tabControlExtra8 = new System.Windows.Forms.TabControlExtra();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage37 = new System.Windows.Forms.TabPage();
            this.tabPage38 = new System.Windows.Forms.TabPage();
            this.tabPage39 = new System.Windows.Forms.TabPage();
            this.tabPage40 = new System.Windows.Forms.TabPage();
            this.tabPage41 = new System.Windows.Forms.TabPage();
            this.tabPage42 = new System.Windows.Forms.TabPage();
            this.tabPage43 = new System.Windows.Forms.TabPage();
            this.tabPage44 = new System.Windows.Forms.TabPage();
            this.tabControlExtra1 = new System.Windows.Forms.TabControlExtra();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage60 = new System.Windows.Forms.TabPage();
            this.tabPage61 = new System.Windows.Forms.TabPage();
            this.tabPage62 = new System.Windows.Forms.TabPage();
            this.tabPage63 = new System.Windows.Forms.TabPage();
            this.tabPage64 = new System.Windows.Forms.TabPage();
            this.tabPage65 = new System.Windows.Forms.TabPage();
            this.tabPage66 = new System.Windows.Forms.TabPage();
            this.tabPage67 = new System.Windows.Forms.TabPage();
            this.tabPage68 = new System.Windows.Forms.TabPage();
            this.tabControlExtra2 = new System.Windows.Forms.TabControlExtra();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabControlExtra6 = new System.Windows.Forms.TabControlExtra();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.tabControlExtra5 = new System.Windows.Forms.TabControlExtra();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.tabControlExtra3 = new System.Windows.Forms.TabControlExtra();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.tabControlExtra4 = new System.Windows.Forms.TabControlExtra();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.tabPage49 = new System.Windows.Forms.TabPage();
            this.tabPage50 = new System.Windows.Forms.TabPage();
            this.tabPage51 = new System.Windows.Forms.TabPage();
            this.tabPage52 = new System.Windows.Forms.TabPage();
            this.tabPage53 = new System.Windows.Forms.TabPage();
            this.tabPage54 = new System.Windows.Forms.TabPage();
            this.tabPage55 = new System.Windows.Forms.TabPage();
            this.tabPage56 = new System.Windows.Forms.TabPage();
            this.tabPage57 = new System.Windows.Forms.TabPage();
            this.tabPage58 = new System.Windows.Forms.TabPage();
            this.tabPage59 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.tabControlExtra7.SuspendLayout();
            this.tabControlExtra9.SuspendLayout();
            this.tabPage69.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControlExtra8.SuspendLayout();
            this.tabPage36.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControlExtra1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControlExtra2.SuspendLayout();
            this.tabControlExtra6.SuspendLayout();
            this.tabControlExtra5.SuspendLayout();
            this.tabControlExtra3.SuspendLayout();
            this.tabControlExtra4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "battery.png");
            this.imageList1.Images.SetKeyName(1, "book_open.png");
            this.imageList1.Images.SetKeyName(2, "brush3.png");
            this.imageList1.Images.SetKeyName(3, "calculator.png");
            this.imageList1.Images.SetKeyName(4, "cd_music.png");
            this.imageList1.Images.SetKeyName(5, "Close");
            this.imageList1.Images.SetKeyName(6, "google_favicon.png");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(60)))), ((int)(((byte)(89)))));
            this.panel1.Controls.Add(this.tabControlExtra7);
            this.panel1.Location = new System.Drawing.Point(0, 482);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 88);
            this.panel1.TabIndex = 8;
            // 
            // tabControlExtra7
            // 
            this.tabControlExtra7.AllowDrop = true;
            this.tabControlExtra7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControlExtra7.Controls.Add(this.tabPage32);
            this.tabControlExtra7.Controls.Add(this.tabPage33);
            this.tabControlExtra7.Controls.Add(this.tabPage34);
            this.tabControlExtra7.Controls.Add(this.tabPage35);
            this.tabControlExtra7.Controls.Add(this.tabPage31);
            this.tabControlExtra7.Controls.Add(this.tabPage45);
            this.tabControlExtra7.Controls.Add(this.tabPage46);
            this.tabControlExtra7.Controls.Add(this.tabPage47);
            this.tabControlExtra7.Controls.Add(this.tabPage48);
            this.tabControlExtra7.DisplayStyle = System.Windows.Forms.TabStyle.VS2010;
            // 
            // 
            // 
            this.tabControlExtra7.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra7.DisplayStyleProvider.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra7.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(167)))), ((int)(((byte)(183)))));
            this.tabControlExtra7.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.tabControlExtra7.DisplayStyleProvider.BorderColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.White;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.White;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.White;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(99)))), ((int)(((byte)(61)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.Black;
            this.tabControlExtra7.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(221)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.Color.Black;
            this.tabControlExtra7.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(102)))), ((int)(((byte)(115)))));
            this.tabControlExtra7.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.Color.Black;
            this.tabControlExtra7.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra7.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra7.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra7.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tabControlExtra7.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra7.DisplayStyleProvider.Overlap = 0;
            this.tabControlExtra7.DisplayStyleProvider.Padding = new System.Drawing.Point(10, 5);
            this.tabControlExtra7.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra7.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra7.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra7.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.Radius = 3;
            this.tabControlExtra7.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra7.DisplayStyleProvider.ShowTabCloser = true;
            this.tabControlExtra7.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorFocused1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorFocused2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra7.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(4);
            this.tabControlExtra7.DisplayStyleProvider.TabPageRadius = 2;
            this.tabControlExtra7.DisplayStyleProvider.TextColorDisabled = System.Drawing.Color.WhiteSmoke;
            this.tabControlExtra7.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra7.DisplayStyleProvider.TextColorHighlighted = System.Drawing.Color.White;
            this.tabControlExtra7.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra7.DisplayStyleProvider.TextColorUnselected = System.Drawing.Color.White;
            this.tabControlExtra7.HotTrack = true;
            this.tabControlExtra7.ImageList = this.imageList1;
            this.tabControlExtra7.Location = new System.Drawing.Point(12, 4);
            this.tabControlExtra7.Name = "tabControlExtra7";
            this.tabControlExtra7.SelectedIndex = 0;
            this.tabControlExtra7.Size = new System.Drawing.Size(493, 74);
            this.tabControlExtra7.TabIndex = 7;
            // 
            // tabPage32
            // 
            this.tabPage32.ImageKey = "book_open.png";
            this.tabPage32.Location = new System.Drawing.Point(4, 28);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage32.Size = new System.Drawing.Size(485, 42);
            this.tabPage32.TabIndex = 1;
            this.tabPage32.Text = "tabPage32";
            this.tabPage32.UseVisualStyleBackColor = true;
            // 
            // tabPage33
            // 
            this.tabPage33.ImageKey = "brush3.png";
            this.tabPage33.Location = new System.Drawing.Point(4, 30);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage33.Size = new System.Drawing.Size(485, 40);
            this.tabPage33.TabIndex = 2;
            this.tabPage33.Text = "tabPage33";
            this.tabPage33.UseVisualStyleBackColor = true;
            // 
            // tabPage34
            // 
            this.tabPage34.ImageKey = "(none)";
            this.tabPage34.Location = new System.Drawing.Point(4, 30);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage34.Size = new System.Drawing.Size(485, 40);
            this.tabPage34.TabIndex = 3;
            this.tabPage34.Text = "tabPage34";
            this.tabPage34.UseVisualStyleBackColor = true;
            // 
            // tabPage35
            // 
            this.tabPage35.ImageKey = "(none)";
            this.tabPage35.Location = new System.Drawing.Point(4, 30);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Size = new System.Drawing.Size(485, 40);
            this.tabPage35.TabIndex = 4;
            this.tabPage35.Text = "tabPage35";
            this.tabPage35.UseVisualStyleBackColor = true;
            // 
            // tabPage31
            // 
            this.tabPage31.Location = new System.Drawing.Point(4, 30);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage31.Size = new System.Drawing.Size(485, 40);
            this.tabPage31.TabIndex = 5;
            this.tabPage31.Text = "tabPage31";
            this.tabPage31.UseVisualStyleBackColor = true;
            // 
            // tabPage45
            // 
            this.tabPage45.Location = new System.Drawing.Point(4, 30);
            this.tabPage45.Name = "tabPage45";
            this.tabPage45.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage45.Size = new System.Drawing.Size(485, 40);
            this.tabPage45.TabIndex = 6;
            this.tabPage45.Text = "tabPage45";
            this.tabPage45.UseVisualStyleBackColor = true;
            // 
            // tabPage46
            // 
            this.tabPage46.Location = new System.Drawing.Point(4, 30);
            this.tabPage46.Name = "tabPage46";
            this.tabPage46.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage46.Size = new System.Drawing.Size(485, 40);
            this.tabPage46.TabIndex = 7;
            this.tabPage46.Text = "tabPage46";
            this.tabPage46.UseVisualStyleBackColor = true;
            // 
            // tabPage47
            // 
            this.tabPage47.Location = new System.Drawing.Point(4, 30);
            this.tabPage47.Name = "tabPage47";
            this.tabPage47.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage47.Size = new System.Drawing.Size(485, 40);
            this.tabPage47.TabIndex = 8;
            this.tabPage47.Text = "tabPage47";
            this.tabPage47.UseVisualStyleBackColor = true;
            // 
            // tabPage48
            // 
            this.tabPage48.Location = new System.Drawing.Point(4, 30);
            this.tabPage48.Name = "tabPage48";
            this.tabPage48.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage48.Size = new System.Drawing.Size(485, 40);
            this.tabPage48.TabIndex = 9;
            this.tabPage48.Text = "tabPage48";
            this.tabPage48.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra9
            // 
            this.tabControlExtra9.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControlExtra9.Controls.Add(this.tabPage69);
            this.tabControlExtra9.Controls.Add(this.tabPage70);
            this.tabControlExtra9.Controls.Add(this.tabPage71);
            this.tabControlExtra9.Controls.Add(this.tabPage72);
            this.tabControlExtra9.Controls.Add(this.tabPage73);
            this.tabControlExtra9.Controls.Add(this.tabPage74);
            this.tabControlExtra9.Controls.Add(this.tabPage75);
            this.tabControlExtra9.Controls.Add(this.tabPage76);
            this.tabControlExtra9.DisplayStyle = System.Windows.Forms.TabStyle.VS2010;
            // 
            // 
            // 
            this.tabControlExtra9.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra9.DisplayStyleProvider.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra9.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(167)))), ((int)(((byte)(183)))));
            this.tabControlExtra9.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra9.DisplayStyleProvider.BorderColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.White;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.White;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.White;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(99)))), ((int)(((byte)(61)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.Black;
            this.tabControlExtra9.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(221)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.Color.Black;
            this.tabControlExtra9.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(102)))), ((int)(((byte)(115)))));
            this.tabControlExtra9.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.Color.Black;
            this.tabControlExtra9.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra9.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra9.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra9.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabControlExtra9.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra9.DisplayStyleProvider.Overlap = 0;
            this.tabControlExtra9.DisplayStyleProvider.Padding = new System.Drawing.Point(6, 5);
            this.tabControlExtra9.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra9.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra9.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra9.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.Radius = 3;
            this.tabControlExtra9.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra9.DisplayStyleProvider.ShowTabCloser = true;
            this.tabControlExtra9.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorFocused1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorFocused2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra9.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(4);
            this.tabControlExtra9.DisplayStyleProvider.TabPageRadius = 2;
            this.tabControlExtra9.DisplayStyleProvider.TextColorDisabled = System.Drawing.Color.WhiteSmoke;
            this.tabControlExtra9.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra9.DisplayStyleProvider.TextColorHighlighted = System.Drawing.Color.White;
            this.tabControlExtra9.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra9.DisplayStyleProvider.TextColorUnselected = System.Drawing.Color.White;
            this.tabControlExtra9.HotTrack = true;
            this.tabControlExtra9.Location = new System.Drawing.Point(14, 63);
            this.tabControlExtra9.Multiline = true;
            this.tabControlExtra9.Name = "tabControlExtra9";
            this.tabControlExtra9.SelectedIndex = 0;
            this.tabControlExtra9.Size = new System.Drawing.Size(166, 317);
            this.tabControlExtra9.TabIndex = 8;
            // 
            // tabPage69
            // 
            this.tabPage69.Controls.Add(this.pictureBox2);
            this.tabPage69.Location = new System.Drawing.Point(74, 4);
            this.tabPage69.Name = "tabPage69";
            this.tabPage69.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage69.Size = new System.Drawing.Size(88, 309);
            this.tabPage69.TabIndex = 0;
            this.tabPage69.Text = "tabPage69";
            this.tabPage69.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.BackColor = System.Drawing.Color.DarkGray;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(88, 309);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // tabPage70
            // 
            this.tabPage70.Location = new System.Drawing.Point(113, 4);
            this.tabPage70.Name = "tabPage70";
            this.tabPage70.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage70.Size = new System.Drawing.Size(49, 309);
            this.tabPage70.TabIndex = 1;
            this.tabPage70.Text = "tabPage70";
            this.tabPage70.UseVisualStyleBackColor = true;
            // 
            // tabPage71
            // 
            this.tabPage71.Location = new System.Drawing.Point(113, 4);
            this.tabPage71.Name = "tabPage71";
            this.tabPage71.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage71.Size = new System.Drawing.Size(49, 309);
            this.tabPage71.TabIndex = 2;
            this.tabPage71.Text = "tabPage71";
            this.tabPage71.UseVisualStyleBackColor = true;
            // 
            // tabPage72
            // 
            this.tabPage72.Location = new System.Drawing.Point(113, 4);
            this.tabPage72.Name = "tabPage72";
            this.tabPage72.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage72.Size = new System.Drawing.Size(49, 309);
            this.tabPage72.TabIndex = 3;
            this.tabPage72.Text = "tabPage72";
            this.tabPage72.UseVisualStyleBackColor = true;
            // 
            // tabPage73
            // 
            this.tabPage73.Location = new System.Drawing.Point(113, 4);
            this.tabPage73.Name = "tabPage73";
            this.tabPage73.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage73.Size = new System.Drawing.Size(49, 309);
            this.tabPage73.TabIndex = 4;
            this.tabPage73.Text = "tabPage73";
            this.tabPage73.UseVisualStyleBackColor = true;
            // 
            // tabPage74
            // 
            this.tabPage74.Location = new System.Drawing.Point(113, 4);
            this.tabPage74.Name = "tabPage74";
            this.tabPage74.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage74.Size = new System.Drawing.Size(49, 309);
            this.tabPage74.TabIndex = 5;
            this.tabPage74.Text = "tabPage74";
            this.tabPage74.UseVisualStyleBackColor = true;
            // 
            // tabPage75
            // 
            this.tabPage75.Location = new System.Drawing.Point(113, 4);
            this.tabPage75.Name = "tabPage75";
            this.tabPage75.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage75.Size = new System.Drawing.Size(49, 309);
            this.tabPage75.TabIndex = 6;
            this.tabPage75.Text = "tabPage75";
            this.tabPage75.UseVisualStyleBackColor = true;
            // 
            // tabPage76
            // 
            this.tabPage76.Location = new System.Drawing.Point(113, 4);
            this.tabPage76.Name = "tabPage76";
            this.tabPage76.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage76.Size = new System.Drawing.Size(49, 309);
            this.tabPage76.TabIndex = 7;
            this.tabPage76.Text = "tabPage76";
            this.tabPage76.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra8
            // 
            this.tabControlExtra8.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControlExtra8.Controls.Add(this.tabPage36);
            this.tabControlExtra8.Controls.Add(this.tabPage37);
            this.tabControlExtra8.Controls.Add(this.tabPage38);
            this.tabControlExtra8.Controls.Add(this.tabPage39);
            this.tabControlExtra8.Controls.Add(this.tabPage40);
            this.tabControlExtra8.Controls.Add(this.tabPage41);
            this.tabControlExtra8.Controls.Add(this.tabPage42);
            this.tabControlExtra8.Controls.Add(this.tabPage43);
            this.tabControlExtra8.Controls.Add(this.tabPage44);
            this.tabControlExtra8.DisplayStyle = System.Windows.Forms.TabStyle.VS2010;
            // 
            // 
            // 
            this.tabControlExtra8.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra8.DisplayStyleProvider.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra8.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(167)))), ((int)(((byte)(183)))));
            this.tabControlExtra8.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(232)))), ((int)(((byte)(166)))));
            this.tabControlExtra8.DisplayStyleProvider.BorderColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.White;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.White;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.White;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(195)))), ((int)(((byte)(101)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(99)))), ((int)(((byte)(61)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.Black;
            this.tabControlExtra8.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(221)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.Color.Black;
            this.tabControlExtra8.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(102)))), ((int)(((byte)(115)))));
            this.tabControlExtra8.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.Color.Black;
            this.tabControlExtra8.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra8.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra8.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra8.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabControlExtra8.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra8.DisplayStyleProvider.Overlap = 0;
            this.tabControlExtra8.DisplayStyleProvider.Padding = new System.Drawing.Point(10, 5);
            this.tabControlExtra8.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra8.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra8.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra8.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.Radius = 3;
            this.tabControlExtra8.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra8.DisplayStyleProvider.ShowTabCloser = true;
            this.tabControlExtra8.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorFocused1 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorFocused2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(205)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(92)))), ((int)(((byte)(116)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(212)))), ((int)(((byte)(223)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(57)))), ((int)(((byte)(85)))));
            this.tabControlExtra8.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(4);
            this.tabControlExtra8.DisplayStyleProvider.TabPageRadius = 3;
            this.tabControlExtra8.DisplayStyleProvider.TextColorDisabled = System.Drawing.Color.WhiteSmoke;
            this.tabControlExtra8.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra8.DisplayStyleProvider.TextColorHighlighted = System.Drawing.Color.White;
            this.tabControlExtra8.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra8.DisplayStyleProvider.TextColorUnselected = System.Drawing.Color.White;
            this.tabControlExtra8.HotTrack = true;
            this.tabControlExtra8.Location = new System.Drawing.Point(10, 576);
            this.tabControlExtra8.Name = "tabControlExtra8";
            this.tabControlExtra8.SelectedIndex = 0;
            this.tabControlExtra8.Size = new System.Drawing.Size(487, 76);
            this.tabControlExtra8.TabIndex = 9;
            // 
            // tabPage36
            // 
            this.tabPage36.Controls.Add(this.pictureBox1);
            this.tabPage36.Location = new System.Drawing.Point(4, 4);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage36.Size = new System.Drawing.Size(479, 45);
            this.tabPage36.TabIndex = 0;
            this.tabPage36.Text = "tabPage36";
            this.tabPage36.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gray;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(480, 45);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage37
            // 
            this.tabPage37.Location = new System.Drawing.Point(4, 4);
            this.tabPage37.Name = "tabPage37";
            this.tabPage37.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage37.Size = new System.Drawing.Size(479, 42);
            this.tabPage37.TabIndex = 1;
            this.tabPage37.Text = "tabPage37";
            this.tabPage37.UseVisualStyleBackColor = true;
            // 
            // tabPage38
            // 
            this.tabPage38.Location = new System.Drawing.Point(4, 4);
            this.tabPage38.Name = "tabPage38";
            this.tabPage38.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage38.Size = new System.Drawing.Size(479, 42);
            this.tabPage38.TabIndex = 2;
            this.tabPage38.Text = "tabPage38";
            this.tabPage38.UseVisualStyleBackColor = true;
            // 
            // tabPage39
            // 
            this.tabPage39.Location = new System.Drawing.Point(4, 4);
            this.tabPage39.Name = "tabPage39";
            this.tabPage39.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage39.Size = new System.Drawing.Size(479, 42);
            this.tabPage39.TabIndex = 3;
            this.tabPage39.Text = "tabPage39";
            this.tabPage39.UseVisualStyleBackColor = true;
            // 
            // tabPage40
            // 
            this.tabPage40.Location = new System.Drawing.Point(4, 4);
            this.tabPage40.Name = "tabPage40";
            this.tabPage40.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage40.Size = new System.Drawing.Size(479, 42);
            this.tabPage40.TabIndex = 4;
            this.tabPage40.Text = "tabPage40";
            this.tabPage40.UseVisualStyleBackColor = true;
            // 
            // tabPage41
            // 
            this.tabPage41.Location = new System.Drawing.Point(4, 4);
            this.tabPage41.Name = "tabPage41";
            this.tabPage41.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage41.Size = new System.Drawing.Size(479, 42);
            this.tabPage41.TabIndex = 5;
            this.tabPage41.Text = "tabPage41";
            this.tabPage41.UseVisualStyleBackColor = true;
            // 
            // tabPage42
            // 
            this.tabPage42.Location = new System.Drawing.Point(4, 4);
            this.tabPage42.Name = "tabPage42";
            this.tabPage42.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage42.Size = new System.Drawing.Size(479, 42);
            this.tabPage42.TabIndex = 6;
            this.tabPage42.Text = "tabPage42";
            this.tabPage42.UseVisualStyleBackColor = true;
            // 
            // tabPage43
            // 
            this.tabPage43.Location = new System.Drawing.Point(4, 4);
            this.tabPage43.Name = "tabPage43";
            this.tabPage43.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage43.Size = new System.Drawing.Size(479, 42);
            this.tabPage43.TabIndex = 7;
            this.tabPage43.Text = "tabPage43";
            this.tabPage43.UseVisualStyleBackColor = true;
            // 
            // tabPage44
            // 
            this.tabPage44.Location = new System.Drawing.Point(4, 4);
            this.tabPage44.Name = "tabPage44";
            this.tabPage44.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage44.Size = new System.Drawing.Size(479, 42);
            this.tabPage44.TabIndex = 8;
            this.tabPage44.Text = "tabPage44";
            this.tabPage44.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra1
            // 
            this.tabControlExtra1.Controls.Add(this.tabPage1);
            this.tabControlExtra1.Controls.Add(this.tabPage2);
            this.tabControlExtra1.Controls.Add(this.tabPage3);
            this.tabControlExtra1.Controls.Add(this.tabPage4);
            this.tabControlExtra1.Controls.Add(this.tabPage5);
            this.tabControlExtra1.Controls.Add(this.tabPage60);
            this.tabControlExtra1.Controls.Add(this.tabPage61);
            this.tabControlExtra1.Controls.Add(this.tabPage62);
            this.tabControlExtra1.Controls.Add(this.tabPage63);
            this.tabControlExtra1.Controls.Add(this.tabPage64);
            this.tabControlExtra1.Controls.Add(this.tabPage65);
            this.tabControlExtra1.Controls.Add(this.tabPage66);
            this.tabControlExtra1.Controls.Add(this.tabPage67);
            this.tabControlExtra1.Controls.Add(this.tabPage68);
            // 
            // 
            // 
            this.tabControlExtra1.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra1.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra1.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra1.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra1.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra1.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra1.DisplayStyleProvider.FocusTrack = true;
            this.tabControlExtra1.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra1.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabControlExtra1.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra1.DisplayStyleProvider.Overlap = 0;
            this.tabControlExtra1.DisplayStyleProvider.Padding = new System.Drawing.Point(6, 3);
            this.tabControlExtra1.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra1.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra1.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.Radius = 2;
            this.tabControlExtra1.DisplayStyleProvider.SelectedTabIsLarger = true;
            this.tabControlExtra1.DisplayStyleProvider.ShowTabCloser = false;
            this.tabControlExtra1.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabColorFocused1 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra1.DisplayStyleProvider.TabColorFocused2 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra1.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabColorSelected1 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra1.DisplayStyleProvider.TabColorSelected2 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra1.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra1.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(4);
            this.tabControlExtra1.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra1.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra1.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra1.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra1.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra1.HotTrack = true;
            this.tabControlExtra1.ImageList = this.imageList1;
            this.tabControlExtra1.Location = new System.Drawing.Point(4, 3);
            this.tabControlExtra1.Name = "tabControlExtra1";
            this.tabControlExtra1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.tabControlExtra1.SelectedIndex = 0;
            this.tabControlExtra1.Size = new System.Drawing.Size(497, 93);
            this.tabControlExtra1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.ImageKey = "(none)";
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(489, 65);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Allge&mein";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(108, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.ImageKey = "(none)";
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(489, 63);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage&2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.ImageKey = "brush3.png";
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(489, 63);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage4
            // 
            this.tabPage4.ImageKey = "(none)";
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(489, 63);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.ImageKey = "cd_music.png";
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(489, 63);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage60
            // 
            this.tabPage60.Location = new System.Drawing.Point(4, 26);
            this.tabPage60.Name = "tabPage60";
            this.tabPage60.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage60.Size = new System.Drawing.Size(489, 63);
            this.tabPage60.TabIndex = 5;
            this.tabPage60.Text = "tabPage60";
            this.tabPage60.UseVisualStyleBackColor = true;
            // 
            // tabPage61
            // 
            this.tabPage61.Location = new System.Drawing.Point(4, 26);
            this.tabPage61.Name = "tabPage61";
            this.tabPage61.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage61.Size = new System.Drawing.Size(489, 63);
            this.tabPage61.TabIndex = 6;
            this.tabPage61.Text = "tabPage61";
            this.tabPage61.UseVisualStyleBackColor = true;
            // 
            // tabPage62
            // 
            this.tabPage62.Location = new System.Drawing.Point(4, 26);
            this.tabPage62.Name = "tabPage62";
            this.tabPage62.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage62.Size = new System.Drawing.Size(489, 63);
            this.tabPage62.TabIndex = 7;
            this.tabPage62.Text = "tabPage62";
            this.tabPage62.UseVisualStyleBackColor = true;
            // 
            // tabPage63
            // 
            this.tabPage63.Location = new System.Drawing.Point(4, 26);
            this.tabPage63.Name = "tabPage63";
            this.tabPage63.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage63.Size = new System.Drawing.Size(489, 63);
            this.tabPage63.TabIndex = 8;
            this.tabPage63.Text = "tabPage63";
            this.tabPage63.UseVisualStyleBackColor = true;
            // 
            // tabPage64
            // 
            this.tabPage64.Location = new System.Drawing.Point(4, 26);
            this.tabPage64.Name = "tabPage64";
            this.tabPage64.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage64.Size = new System.Drawing.Size(489, 63);
            this.tabPage64.TabIndex = 9;
            this.tabPage64.Text = "tabPage64";
            this.tabPage64.UseVisualStyleBackColor = true;
            // 
            // tabPage65
            // 
            this.tabPage65.Location = new System.Drawing.Point(4, 26);
            this.tabPage65.Name = "tabPage65";
            this.tabPage65.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage65.Size = new System.Drawing.Size(489, 63);
            this.tabPage65.TabIndex = 10;
            this.tabPage65.Text = "tabPage65";
            this.tabPage65.UseVisualStyleBackColor = true;
            // 
            // tabPage66
            // 
            this.tabPage66.Location = new System.Drawing.Point(4, 26);
            this.tabPage66.Name = "tabPage66";
            this.tabPage66.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage66.Size = new System.Drawing.Size(489, 63);
            this.tabPage66.TabIndex = 11;
            this.tabPage66.Text = "tabPage66";
            this.tabPage66.UseVisualStyleBackColor = true;
            // 
            // tabPage67
            // 
            this.tabPage67.Location = new System.Drawing.Point(4, 26);
            this.tabPage67.Name = "tabPage67";
            this.tabPage67.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage67.Size = new System.Drawing.Size(489, 63);
            this.tabPage67.TabIndex = 12;
            this.tabPage67.Text = "tabPage67";
            this.tabPage67.UseVisualStyleBackColor = true;
            // 
            // tabPage68
            // 
            this.tabPage68.Location = new System.Drawing.Point(4, 26);
            this.tabPage68.Name = "tabPage68";
            this.tabPage68.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage68.Size = new System.Drawing.Size(489, 63);
            this.tabPage68.TabIndex = 13;
            this.tabPage68.Text = "tabPage68";
            this.tabPage68.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra2
            // 
            this.tabControlExtra2.Controls.Add(this.tabPage6);
            this.tabControlExtra2.Controls.Add(this.tabPage7);
            this.tabControlExtra2.Controls.Add(this.tabPage8);
            this.tabControlExtra2.Controls.Add(this.tabPage9);
            this.tabControlExtra2.Controls.Add(this.tabPage10);
            this.tabControlExtra2.DisplayStyle = System.Windows.Forms.TabStyle.VisualStudio;
            // 
            // 
            // 
            this.tabControlExtra2.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra2.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra2.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra2.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra2.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorFocused = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorSelected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra2.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra2.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra2.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tabControlExtra2.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra2.DisplayStyleProvider.Overlap = 7;
            this.tabControlExtra2.DisplayStyleProvider.Padding = new System.Drawing.Point(14, 1);
            this.tabControlExtra2.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra2.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra2.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra2.DisplayStyleProvider.ShowTabCloser = false;
            this.tabControlExtra2.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabColorFocused1 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra2.DisplayStyleProvider.TabColorFocused2 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra2.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabColorSelected1 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra2.DisplayStyleProvider.TabColorSelected2 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra2.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra2.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(1);
            this.tabControlExtra2.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra2.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra2.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra2.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra2.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra2.HotTrack = true;
            this.tabControlExtra2.ImageList = this.imageList1;
            this.tabControlExtra2.Location = new System.Drawing.Point(12, 94);
            this.tabControlExtra2.Name = "tabControlExtra2";
            this.tabControlExtra2.SelectedIndex = 0;
            this.tabControlExtra2.Size = new System.Drawing.Size(497, 72);
            this.tabControlExtra2.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.ImageKey = "(none)";
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(489, 46);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Allgemein";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.ImageKey = "book_open.png";
            this.tabPage7.Location = new System.Drawing.Point(4, 24);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(489, 44);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.ImageKey = "(none)";
            this.tabPage8.Location = new System.Drawing.Point(4, 24);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(489, 44);
            this.tabPage8.TabIndex = 2;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.ImageKey = "(none)";
            this.tabPage9.Location = new System.Drawing.Point(4, 24);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(489, 44);
            this.tabPage9.TabIndex = 3;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            this.tabPage10.ImageKey = "cd_music.png";
            this.tabPage10.Location = new System.Drawing.Point(4, 24);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(489, 44);
            this.tabPage10.TabIndex = 4;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra6
            // 
            this.tabControlExtra6.AllowDrop = true;
            this.tabControlExtra6.Controls.Add(this.tabPage26);
            this.tabControlExtra6.Controls.Add(this.tabPage27);
            this.tabControlExtra6.Controls.Add(this.tabPage28);
            this.tabControlExtra6.Controls.Add(this.tabPage29);
            this.tabControlExtra6.Controls.Add(this.tabPage30);
            this.tabControlExtra6.DisplayStyle = System.Windows.Forms.TabStyle.IE8;
            // 
            // 
            // 
            this.tabControlExtra6.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra6.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra6.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra6.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra6.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.White;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.Black;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.Red;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.Black;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.Black;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra6.DisplayStyleProvider.FocusColor = System.Drawing.Color.White;
            this.tabControlExtra6.DisplayStyleProvider.FocusTrack = true;
            this.tabControlExtra6.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra6.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tabControlExtra6.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra6.DisplayStyleProvider.Overlap = 0;
            this.tabControlExtra6.DisplayStyleProvider.Padding = new System.Drawing.Point(6, 5);
            this.tabControlExtra6.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.Radius = 3;
            this.tabControlExtra6.DisplayStyleProvider.SelectedTabIsLarger = true;
            this.tabControlExtra6.DisplayStyleProvider.ShowTabCloser = true;
            this.tabControlExtra6.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorFocused1 = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorFocused2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(252)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(223)))), ((int)(((byte)(255)))));
            this.tabControlExtra6.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(1);
            this.tabControlExtra6.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra6.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra6.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra6.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra6.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra6.HotTrack = true;
            this.tabControlExtra6.ImageList = this.imageList1;
            this.tabControlExtra6.Location = new System.Drawing.Point(12, 250);
            this.tabControlExtra6.Name = "tabControlExtra6";
            this.tabControlExtra6.RightToLeftLayout = true;
            this.tabControlExtra6.SelectedIndex = 0;
            this.tabControlExtra6.Size = new System.Drawing.Size(497, 72);
            this.tabControlExtra6.TabIndex = 4;
            // 
            // tabPage26
            // 
            this.tabPage26.ImageKey = "google_favicon.png";
            this.tabPage26.Location = new System.Drawing.Point(4, 28);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(489, 40);
            this.tabPage26.TabIndex = 0;
            this.tabPage26.Text = "Allgemein";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // tabPage27
            // 
            this.tabPage27.ImageKey = "google_favicon.png";
            this.tabPage27.Location = new System.Drawing.Point(4, 30);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage27.Size = new System.Drawing.Size(489, 38);
            this.tabPage27.TabIndex = 1;
            this.tabPage27.Text = "tabPage27";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // tabPage28
            // 
            this.tabPage28.ImageKey = "(none)";
            this.tabPage28.Location = new System.Drawing.Point(4, 30);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage28.Size = new System.Drawing.Size(489, 38);
            this.tabPage28.TabIndex = 2;
            this.tabPage28.Text = "tabPage28";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // tabPage29
            // 
            this.tabPage29.ImageKey = "(none)";
            this.tabPage29.Location = new System.Drawing.Point(4, 30);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage29.Size = new System.Drawing.Size(489, 38);
            this.tabPage29.TabIndex = 3;
            this.tabPage29.Text = "tabPage29";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // tabPage30
            // 
            this.tabPage30.ImageKey = "google_favicon.png";
            this.tabPage30.Location = new System.Drawing.Point(4, 30);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Size = new System.Drawing.Size(489, 38);
            this.tabPage30.TabIndex = 4;
            this.tabPage30.Text = "tabPage30";
            this.tabPage30.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra5
            // 
            this.tabControlExtra5.Controls.Add(this.tabPage21);
            this.tabControlExtra5.Controls.Add(this.tabPage22);
            this.tabControlExtra5.Controls.Add(this.tabPage23);
            this.tabControlExtra5.Controls.Add(this.tabPage24);
            this.tabControlExtra5.Controls.Add(this.tabPage25);
            this.tabControlExtra5.DisplayStyle = System.Windows.Forms.TabStyle.Chrome;
            // 
            // 
            // 
            this.tabControlExtra5.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra5.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra5.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra5.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra5.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra5.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(159)))), ((int)(((byte)(148)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(159)))), ((int)(((byte)(148)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(159)))), ((int)(((byte)(148)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(106)))), ((int)(((byte)(94)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(106)))), ((int)(((byte)(94)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(106)))), ((int)(((byte)(94)))));
            this.tabControlExtra5.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorFocused = System.Drawing.Color.Black;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.Color.White;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.Color.Black;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.Color.White;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorSelected = System.Drawing.Color.Black;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.Color.White;
            this.tabControlExtra5.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra5.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra5.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra5.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tabControlExtra5.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra5.DisplayStyleProvider.Overlap = 16;
            this.tabControlExtra5.DisplayStyleProvider.Padding = new System.Drawing.Point(7, 5);
            this.tabControlExtra5.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra5.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra5.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.Radius = 16;
            this.tabControlExtra5.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra5.DisplayStyleProvider.ShowTabCloser = true;
            this.tabControlExtra5.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabColorFocused1 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra5.DisplayStyleProvider.TabColorFocused2 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra5.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabColorSelected1 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra5.DisplayStyleProvider.TabColorSelected2 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra5.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra5.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(1);
            this.tabControlExtra5.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra5.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra5.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra5.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra5.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra5.HotTrack = true;
            this.tabControlExtra5.ImageList = this.imageList1;
            this.tabControlExtra5.Location = new System.Drawing.Point(12, 172);
            this.tabControlExtra5.Name = "tabControlExtra5";
            this.tabControlExtra5.RightToLeftLayout = true;
            this.tabControlExtra5.SelectedIndex = 0;
            this.tabControlExtra5.Size = new System.Drawing.Size(497, 72);
            this.tabControlExtra5.TabIndex = 3;
            // 
            // tabPage21
            // 
            this.tabPage21.ImageKey = "(none)";
            this.tabPage21.Location = new System.Drawing.Point(4, 28);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(489, 40);
            this.tabPage21.TabIndex = 0;
            this.tabPage21.Text = "Allgemein";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // tabPage22
            // 
            this.tabPage22.ImageKey = "google_favicon.png";
            this.tabPage22.Location = new System.Drawing.Point(4, 30);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(489, 38);
            this.tabPage22.TabIndex = 1;
            this.tabPage22.Text = "tabPage22";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // tabPage23
            // 
            this.tabPage23.ImageKey = "(none)";
            this.tabPage23.Location = new System.Drawing.Point(4, 30);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(489, 38);
            this.tabPage23.TabIndex = 2;
            this.tabPage23.Text = "tabPage23";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // tabPage24
            // 
            this.tabPage24.ImageKey = "(none)";
            this.tabPage24.Location = new System.Drawing.Point(4, 30);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(489, 38);
            this.tabPage24.TabIndex = 3;
            this.tabPage24.Text = "tabPage24";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // tabPage25
            // 
            this.tabPage25.ImageKey = "google_favicon.png";
            this.tabPage25.Location = new System.Drawing.Point(4, 30);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Size = new System.Drawing.Size(489, 38);
            this.tabPage25.TabIndex = 4;
            this.tabPage25.Text = "tabPage25";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra3
            // 
            this.tabControlExtra3.Controls.Add(this.tabPage11);
            this.tabControlExtra3.Controls.Add(this.tabPage12);
            this.tabControlExtra3.Controls.Add(this.tabPage13);
            this.tabControlExtra3.Controls.Add(this.tabPage14);
            this.tabControlExtra3.Controls.Add(this.tabPage15);
            this.tabControlExtra3.DisplayStyle = System.Windows.Forms.TabStyle.Rounded;
            // 
            // 
            // 
            this.tabControlExtra3.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra3.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra3.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra3.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra3.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorFocused = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorSelected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra3.DisplayStyleProvider.FocusTrack = false;
            this.tabControlExtra3.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra3.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tabControlExtra3.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra3.DisplayStyleProvider.Overlap = 5;
            this.tabControlExtra3.DisplayStyleProvider.Padding = new System.Drawing.Point(6, 3);
            this.tabControlExtra3.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra3.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(252)))));
            this.tabControlExtra3.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra3.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.Radius = 10;
            this.tabControlExtra3.DisplayStyleProvider.SelectedTabIsLarger = false;
            this.tabControlExtra3.DisplayStyleProvider.ShowTabCloser = false;
            this.tabControlExtra3.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.TabColorFocused1 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra3.DisplayStyleProvider.TabColorFocused2 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra3.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(252)))));
            this.tabControlExtra3.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(237)))), ((int)(((byte)(252)))));
            this.tabControlExtra3.DisplayStyleProvider.TabColorSelected1 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra3.DisplayStyleProvider.TabColorSelected2 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra3.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra3.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(1);
            this.tabControlExtra3.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra3.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra3.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra3.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra3.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra3.HotTrack = true;
            this.tabControlExtra3.ImageList = this.imageList1;
            this.tabControlExtra3.Location = new System.Drawing.Point(12, 328);
            this.tabControlExtra3.Name = "tabControlExtra3";
            this.tabControlExtra3.RightToLeftLayout = true;
            this.tabControlExtra3.SelectedIndex = 0;
            this.tabControlExtra3.Size = new System.Drawing.Size(497, 72);
            this.tabControlExtra3.TabIndex = 5;
            // 
            // tabPage11
            // 
            this.tabPage11.ImageKey = "(none)";
            this.tabPage11.Location = new System.Drawing.Point(4, 24);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(489, 44);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "Allgemein";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tabPage12
            // 
            this.tabPage12.ImageKey = "(none)";
            this.tabPage12.Location = new System.Drawing.Point(4, 26);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(489, 42);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "tabPage12";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabPage13
            // 
            this.tabPage13.ImageKey = "brush3.png";
            this.tabPage13.Location = new System.Drawing.Point(4, 26);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(489, 42);
            this.tabPage13.TabIndex = 2;
            this.tabPage13.Text = "tabPage13";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tabPage14
            // 
            this.tabPage14.ImageKey = "calculator.png";
            this.tabPage14.Location = new System.Drawing.Point(4, 26);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(489, 42);
            this.tabPage14.TabIndex = 3;
            this.tabPage14.Text = "tabPage14";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabPage15
            // 
            this.tabPage15.ImageKey = "cd_music.png";
            this.tabPage15.Location = new System.Drawing.Point(4, 26);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(489, 42);
            this.tabPage15.TabIndex = 4;
            this.tabPage15.Text = "tabPage15";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // tabControlExtra4
            // 
            this.tabControlExtra4.Controls.Add(this.tabPage16);
            this.tabControlExtra4.Controls.Add(this.tabPage17);
            this.tabControlExtra4.Controls.Add(this.tabPage18);
            this.tabControlExtra4.Controls.Add(this.tabPage19);
            this.tabControlExtra4.Controls.Add(this.tabPage20);
            this.tabControlExtra4.Controls.Add(this.tabPage49);
            this.tabControlExtra4.Controls.Add(this.tabPage50);
            this.tabControlExtra4.Controls.Add(this.tabPage51);
            this.tabControlExtra4.Controls.Add(this.tabPage52);
            this.tabControlExtra4.Controls.Add(this.tabPage53);
            this.tabControlExtra4.Controls.Add(this.tabPage54);
            this.tabControlExtra4.Controls.Add(this.tabPage55);
            this.tabControlExtra4.Controls.Add(this.tabPage56);
            this.tabControlExtra4.Controls.Add(this.tabPage57);
            this.tabControlExtra4.Controls.Add(this.tabPage58);
            this.tabControlExtra4.Controls.Add(this.tabPage59);
            this.tabControlExtra4.DisplayStyle = System.Windows.Forms.TabStyle.Angled;
            // 
            // 
            // 
            this.tabControlExtra4.DisplayStyleProvider.BlendStyle = System.Windows.Forms.BlendStyle.Normal;
            this.tabControlExtra4.DisplayStyleProvider.BorderColorDisabled = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra4.DisplayStyleProvider.BorderColorFocused = System.Drawing.Color.Red;
            this.tabControlExtra4.DisplayStyleProvider.BorderColorHighlighted = System.Drawing.Color.Black;
            this.tabControlExtra4.DisplayStyleProvider.BorderColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(157)))), ((int)(((byte)(185)))));
            this.tabControlExtra4.DisplayStyleProvider.BorderColorUnselected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonFillColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorFocused = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorFocusedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorHighlighted = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorHighlightedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorSelected = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorSelectedActive = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserButtonOutlineColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorFocused = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorFocusedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorHighlighted = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorHighlightedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorSelected = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorSelectedActive = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.CloserColorUnselected = System.Drawing.Color.Empty;
            this.tabControlExtra4.DisplayStyleProvider.FocusColor = System.Drawing.Color.Maroon;
            this.tabControlExtra4.DisplayStyleProvider.FocusTrack = true;
            this.tabControlExtra4.DisplayStyleProvider.HotTrack = true;
            this.tabControlExtra4.DisplayStyleProvider.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tabControlExtra4.DisplayStyleProvider.Opacity = 1F;
            this.tabControlExtra4.DisplayStyleProvider.Overlap = 7;
            this.tabControlExtra4.DisplayStyleProvider.Padding = new System.Drawing.Point(10, 3);
            this.tabControlExtra4.DisplayStyleProvider.PageBackgroundColorDisabled = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.PageBackgroundColorFocused = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra4.DisplayStyleProvider.PageBackgroundColorHighlighted = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(252)))));
            this.tabControlExtra4.DisplayStyleProvider.PageBackgroundColorSelected = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra4.DisplayStyleProvider.PageBackgroundColorUnselected = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.Radius = 10;
            this.tabControlExtra4.DisplayStyleProvider.SelectedTabIsLarger = true;
            this.tabControlExtra4.DisplayStyleProvider.ShowTabCloser = false;
            this.tabControlExtra4.DisplayStyleProvider.TabColorDisabled1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.TabColorDisabled2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.TabColorFocused1 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra4.DisplayStyleProvider.TabColorFocused2 = System.Drawing.SystemColors.ControlLight;
            this.tabControlExtra4.DisplayStyleProvider.TabColorHighLighted1 = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(244)))), ((int)(((byte)(252)))));
            this.tabControlExtra4.DisplayStyleProvider.TabColorHighLighted2 = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(237)))), ((int)(((byte)(252)))));
            this.tabControlExtra4.DisplayStyleProvider.TabColorSelected1 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra4.DisplayStyleProvider.TabColorSelected2 = System.Drawing.SystemColors.ControlLightLight;
            this.tabControlExtra4.DisplayStyleProvider.TabColorUnSelected1 = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.TabColorUnSelected2 = System.Drawing.SystemColors.Control;
            this.tabControlExtra4.DisplayStyleProvider.TabPageMargin = new System.Windows.Forms.Padding(4, 1, 4, 1);
            this.tabControlExtra4.DisplayStyleProvider.TextColorDisabled = System.Drawing.SystemColors.ControlDark;
            this.tabControlExtra4.DisplayStyleProvider.TextColorFocused = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra4.DisplayStyleProvider.TextColorHighlighted = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra4.DisplayStyleProvider.TextColorSelected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra4.DisplayStyleProvider.TextColorUnselected = System.Drawing.SystemColors.ControlText;
            this.tabControlExtra4.HotTrack = true;
            this.tabControlExtra4.ImageList = this.imageList1;
            this.tabControlExtra4.Location = new System.Drawing.Point(12, 406);
            this.tabControlExtra4.Name = "tabControlExtra4";
            this.tabControlExtra4.SelectedIndex = 0;
            this.tabControlExtra4.Size = new System.Drawing.Size(497, 74);
            this.tabControlExtra4.TabIndex = 6;
            // 
            // tabPage16
            // 
            this.tabPage16.ImageKey = "battery.png";
            this.tabPage16.Location = new System.Drawing.Point(4, 24);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(489, 46);
            this.tabPage16.TabIndex = 0;
            this.tabPage16.Text = "Allgemein";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabPage17
            // 
            this.tabPage17.ImageKey = "book_open.png";
            this.tabPage17.Location = new System.Drawing.Point(4, 26);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(489, 44);
            this.tabPage17.TabIndex = 1;
            this.tabPage17.Text = "tabPage17";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // tabPage18
            // 
            this.tabPage18.ImageKey = "brush3.png";
            this.tabPage18.Location = new System.Drawing.Point(4, 26);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(489, 44);
            this.tabPage18.TabIndex = 2;
            this.tabPage18.Text = "tabPage18";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // tabPage19
            // 
            this.tabPage19.ImageKey = "(none)";
            this.tabPage19.Location = new System.Drawing.Point(4, 26);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(489, 44);
            this.tabPage19.TabIndex = 3;
            this.tabPage19.Text = "tabPage19";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // tabPage20
            // 
            this.tabPage20.ImageKey = "(none)";
            this.tabPage20.Location = new System.Drawing.Point(4, 26);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(489, 44);
            this.tabPage20.TabIndex = 4;
            this.tabPage20.Text = "tabPage20";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // tabPage49
            // 
            this.tabPage49.Location = new System.Drawing.Point(4, 26);
            this.tabPage49.Name = "tabPage49";
            this.tabPage49.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage49.Size = new System.Drawing.Size(489, 44);
            this.tabPage49.TabIndex = 5;
            this.tabPage49.Text = "tabPage49";
            this.tabPage49.UseVisualStyleBackColor = true;
            // 
            // tabPage50
            // 
            this.tabPage50.Location = new System.Drawing.Point(4, 26);
            this.tabPage50.Name = "tabPage50";
            this.tabPage50.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage50.Size = new System.Drawing.Size(489, 44);
            this.tabPage50.TabIndex = 6;
            this.tabPage50.Text = "tabPage50";
            this.tabPage50.UseVisualStyleBackColor = true;
            // 
            // tabPage51
            // 
            this.tabPage51.Location = new System.Drawing.Point(4, 26);
            this.tabPage51.Name = "tabPage51";
            this.tabPage51.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage51.Size = new System.Drawing.Size(489, 44);
            this.tabPage51.TabIndex = 7;
            this.tabPage51.Text = "tabPage51";
            this.tabPage51.UseVisualStyleBackColor = true;
            // 
            // tabPage52
            // 
            this.tabPage52.Location = new System.Drawing.Point(4, 26);
            this.tabPage52.Name = "tabPage52";
            this.tabPage52.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage52.Size = new System.Drawing.Size(489, 44);
            this.tabPage52.TabIndex = 8;
            this.tabPage52.Text = "tabPage52";
            this.tabPage52.UseVisualStyleBackColor = true;
            // 
            // tabPage53
            // 
            this.tabPage53.Location = new System.Drawing.Point(4, 26);
            this.tabPage53.Name = "tabPage53";
            this.tabPage53.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage53.Size = new System.Drawing.Size(489, 44);
            this.tabPage53.TabIndex = 9;
            this.tabPage53.Text = "tabPage53";
            this.tabPage53.UseVisualStyleBackColor = true;
            // 
            // tabPage54
            // 
            this.tabPage54.Location = new System.Drawing.Point(4, 26);
            this.tabPage54.Name = "tabPage54";
            this.tabPage54.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage54.Size = new System.Drawing.Size(489, 44);
            this.tabPage54.TabIndex = 10;
            this.tabPage54.Text = "tabPage54";
            this.tabPage54.UseVisualStyleBackColor = true;
            // 
            // tabPage55
            // 
            this.tabPage55.Location = new System.Drawing.Point(4, 26);
            this.tabPage55.Name = "tabPage55";
            this.tabPage55.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage55.Size = new System.Drawing.Size(489, 44);
            this.tabPage55.TabIndex = 11;
            this.tabPage55.Text = "tabPage55";
            this.tabPage55.UseVisualStyleBackColor = true;
            // 
            // tabPage56
            // 
            this.tabPage56.Location = new System.Drawing.Point(4, 26);
            this.tabPage56.Name = "tabPage56";
            this.tabPage56.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage56.Size = new System.Drawing.Size(489, 44);
            this.tabPage56.TabIndex = 12;
            this.tabPage56.Text = "tabPage56";
            this.tabPage56.UseVisualStyleBackColor = true;
            // 
            // tabPage57
            // 
            this.tabPage57.Location = new System.Drawing.Point(4, 26);
            this.tabPage57.Name = "tabPage57";
            this.tabPage57.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage57.Size = new System.Drawing.Size(489, 44);
            this.tabPage57.TabIndex = 13;
            this.tabPage57.Text = "tabPage57";
            this.tabPage57.UseVisualStyleBackColor = true;
            // 
            // tabPage58
            // 
            this.tabPage58.Location = new System.Drawing.Point(4, 26);
            this.tabPage58.Name = "tabPage58";
            this.tabPage58.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage58.Size = new System.Drawing.Size(489, 44);
            this.tabPage58.TabIndex = 14;
            this.tabPage58.Text = "tabPage58";
            this.tabPage58.UseVisualStyleBackColor = true;
            // 
            // tabPage59
            // 
            this.tabPage59.Location = new System.Drawing.Point(4, 26);
            this.tabPage59.Name = "tabPage59";
            this.tabPage59.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage59.Size = new System.Drawing.Size(489, 44);
            this.tabPage59.TabIndex = 15;
            this.tabPage59.Text = "tabPage59";
            this.tabPage59.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.tabControlExtra9);
            this.panel2.Location = new System.Drawing.Point(543, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(195, 402);
            this.panel2.TabIndex = 11;
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(775, 670);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tabControlExtra8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControlExtra2);
            this.Controls.Add(this.tabControlExtra1);
            this.Controls.Add(this.tabControlExtra6);
            this.Controls.Add(this.tabControlExtra5);
            this.Controls.Add(this.tabControlExtra3);
            this.Controls.Add(this.tabControlExtra4);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(526, 521);
            this.Name = "MainForm";
            this.Text = "TabControl Demo";
            this.panel1.ResumeLayout(false);
            this.tabControlExtra7.ResumeLayout(false);
            this.tabControlExtra9.ResumeLayout(false);
            this.tabPage69.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControlExtra8.ResumeLayout(false);
            this.tabPage36.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControlExtra1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControlExtra2.ResumeLayout(false);
            this.tabControlExtra6.ResumeLayout(false);
            this.tabControlExtra5.ResumeLayout(false);
            this.tabControlExtra3.ResumeLayout(false);
            this.tabControlExtra4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TabPage tabPage35;
		private System.Windows.Forms.TabPage tabPage34;
		private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.TabPage tabPage32;
		private System.Windows.Forms.TabControlExtra tabControlExtra7;
		private System.Windows.Forms.TabPage tabPage30;
		private System.Windows.Forms.TabPage tabPage29;
		private System.Windows.Forms.TabPage tabPage28;
		private System.Windows.Forms.TabPage tabPage27;
		private System.Windows.Forms.TabPage tabPage26;
		private System.Windows.Forms.TabControlExtra tabControlExtra6;
		private System.Windows.Forms.TabPage tabPage25;
		private System.Windows.Forms.TabPage tabPage24;
		private System.Windows.Forms.TabPage tabPage23;
		private System.Windows.Forms.TabPage tabPage22;
		private System.Windows.Forms.TabPage tabPage21;
		private System.Windows.Forms.TabControlExtra tabControlExtra5;
		private System.Windows.Forms.TabPage tabPage20;
		private System.Windows.Forms.TabPage tabPage19;
		private System.Windows.Forms.TabPage tabPage18;
		private System.Windows.Forms.TabPage tabPage17;
		private System.Windows.Forms.TabPage tabPage16;
		private System.Windows.Forms.TabControlExtra tabControlExtra4;
		private System.Windows.Forms.TabPage tabPage15;
		private System.Windows.Forms.TabPage tabPage14;
		private System.Windows.Forms.TabPage tabPage13;
		private System.Windows.Forms.TabPage tabPage12;
		private System.Windows.Forms.TabPage tabPage11;
		private System.Windows.Forms.TabControlExtra tabControlExtra3;
		private System.Windows.Forms.TabPage tabPage10;
		private System.Windows.Forms.TabPage tabPage9;
		private System.Windows.Forms.TabPage tabPage8;
		private System.Windows.Forms.TabPage tabPage7;
		private System.Windows.Forms.TabPage tabPage6;
		private System.Windows.Forms.TabControlExtra tabControlExtra2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage5;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControlExtra tabControlExtra1;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabControlExtra tabControlExtra8;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.TabPage tabPage37;
        private System.Windows.Forms.TabPage tabPage38;
        private System.Windows.Forms.TabPage tabPage39;
        private System.Windows.Forms.TabPage tabPage40;
        private System.Windows.Forms.TabPage tabPage41;
        private System.Windows.Forms.TabPage tabPage42;
        private System.Windows.Forms.TabPage tabPage43;
        private System.Windows.Forms.TabPage tabPage44;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.TabPage tabPage45;
        private System.Windows.Forms.TabPage tabPage46;
        private System.Windows.Forms.TabPage tabPage47;
        private System.Windows.Forms.TabPage tabPage48;
        private System.Windows.Forms.TabPage tabPage49;
        private System.Windows.Forms.TabPage tabPage50;
        private System.Windows.Forms.TabPage tabPage51;
        private System.Windows.Forms.TabPage tabPage52;
        private System.Windows.Forms.TabPage tabPage53;
        private System.Windows.Forms.TabPage tabPage54;
        private System.Windows.Forms.TabPage tabPage55;
        private System.Windows.Forms.TabPage tabPage56;
        private System.Windows.Forms.TabPage tabPage57;
        private System.Windows.Forms.TabPage tabPage58;
        private System.Windows.Forms.TabPage tabPage59;
        private System.Windows.Forms.TabPage tabPage60;
        private System.Windows.Forms.TabPage tabPage61;
        private System.Windows.Forms.TabPage tabPage62;
        private System.Windows.Forms.TabPage tabPage63;
        private System.Windows.Forms.TabPage tabPage64;
        private System.Windows.Forms.TabPage tabPage65;
        private System.Windows.Forms.TabPage tabPage66;
        private System.Windows.Forms.TabPage tabPage67;
        private System.Windows.Forms.TabPage tabPage68;
        private System.Windows.Forms.TabControlExtra tabControlExtra9;
        private System.Windows.Forms.TabPage tabPage69;
        private System.Windows.Forms.TabPage tabPage70;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage71;
        private System.Windows.Forms.TabPage tabPage72;
        private System.Windows.Forms.TabPage tabPage73;
        private System.Windows.Forms.TabPage tabPage74;
        private System.Windows.Forms.TabPage tabPage75;
        private System.Windows.Forms.TabPage tabPage76;
        private System.Windows.Forms.Panel panel2;
	}
}
