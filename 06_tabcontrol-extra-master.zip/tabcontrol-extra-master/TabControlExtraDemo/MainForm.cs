﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Security.Permissions;
using System.Windows.Forms;

namespace CSCustomTabControlDemo
{
	public partial class MainForm : System.Windows.Forms.Form
	{
		public MainForm() {
			InitializeComponent();
		}
		
	}
}
