﻿/*
 * This code is provided under the Code Project Open Licence (CPOL)
 * See http://www.codeproject.com/info/cpol10.aspx for details
 */

using System.Windows.Forms;

namespace System.Windows.Forms {
    public enum BlendStyle {
        Normal = 0,
        Glass = 1
    }

}