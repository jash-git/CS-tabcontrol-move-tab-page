using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TabbedMDIChildForms
{
    public partial class newForm2 : Form
    {
        public newForm2()
        {
            InitializeComponent();
        }
    }
}