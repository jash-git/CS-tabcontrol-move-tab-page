# CSharpCustomTabs
A TabControl component where tabs have a close button.

<a href="http://imgur.com/oCJvc3r"><img src="http://i.imgur.com/oCJvc3r.png" title="source: imgur.com" /></a>
