# Fancy-TabControl
New beautiful and nice tab control ,easy to use on your project 
this code based on current tab control , but i enhanced it to look fancy and beautful 
all you need adding classes in your Project , you find new tab control on toolbox , 
just drag it in weare in your forms , it works fine :D 
Enjoy using it 
![alt text](https://github.com/esaaco/Fancy-TabControl/blob/master/FancyTabControl.JPG)
