Public Class TabControlDnD : Inherits System.Windows.Forms.TabControl	'Drag and Drop - reordering support

	Private _SourceTabPage As System.Windows.Forms.TabPage = Nothing

	Public Sub New()
		MyBase.New()
	End Sub

	Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
		If (e.Button = Windows.Forms.MouseButtons.Left) AndAlso (MyBase.SelectedTab IsNot Nothing) AndAlso (Not MyBase.GetTabRect(MyBase.SelectedIndex).IsEmpty) Then
			Me._SourceTabPage = MyBase.SelectedTab
		End If
		MyBase.OnMouseDown(e)
	End Sub

	Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
		If (e.Button = Windows.Forms.MouseButtons.Left) AndAlso (Me._SourceTabPage IsNot Nothing) Then
			Dim currTabPage As System.Windows.Forms.TabPage = GetTabPageFromXY(e.X, e.Y)
			If (currTabPage IsNot Nothing) Then
				Dim currRect As Drawing.Rectangle = MyBase.GetTabRect(MyBase.TabPages.IndexOf(currTabPage))
				If (MyBase.TabPages.IndexOf(currTabPage) < MyBase.TabPages.IndexOf(Me._SourceTabPage)) Then
					MyBase.Cursor = Cursors.PanWest
				ElseIf (MyBase.TabPages.IndexOf(currTabPage) > MyBase.TabPages.IndexOf(Me._SourceTabPage)) Then
					MyBase.Cursor = Cursors.PanEast
				Else 'tab is same as current
					MyBase.Cursor = Cursors.Default
				End If
			Else 'no tab selected
				Me.Cursor = Cursors.No
			End If
		Else
			Me.Cursor = Cursors.Default
		End If
		MyBase.OnMouseMove(e)
	End Sub

	Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
		If (e.Button = Windows.Forms.MouseButtons.Left) AndAlso (Me._SourceTabPage IsNot Nothing) Then
			Dim currTabPage As System.Windows.Forms.TabPage = GetTabPageFromXY(e.X, e.Y)
			If (currTabPage IsNot Nothing) AndAlso (Not currTabPage.Equals(Me._SourceTabPage)) Then
				Dim currRect As Drawing.Rectangle = MyBase.GetTabRect(MyBase.TabPages.IndexOf(currTabPage))
				If (MyBase.TabPages.IndexOf(currTabPage) < MyBase.TabPages.IndexOf(Me._SourceTabPage)) Then
					MyBase.TabPages.Remove(Me._SourceTabPage)
					MyBase.TabPages.Insert(MyBase.TabPages.IndexOf(currTabPage), Me._SourceTabPage)
					MyBase.SelectedTab = Me._SourceTabPage
				ElseIf (MyBase.TabPages.IndexOf(currTabPage) > MyBase.TabPages.IndexOf(Me._SourceTabPage)) Then
					MyBase.TabPages.Remove(Me._SourceTabPage)
					MyBase.TabPages.Insert(MyBase.TabPages.IndexOf(currTabPage) + 1, Me._SourceTabPage)
					MyBase.SelectedTab = Me._SourceTabPage
				End If
			End If
		End If
		Me._SourceTabPage = Nothing
		MyBase.Cursor = Cursors.Default
		MyBase.OnMouseUp(e)
	End Sub


	Private Function GetTabPageFromXY(ByVal x As Integer, ByVal y As Integer) As TabPage
		For i As Integer = 0 To MyBase.TabPages.Count - 1
			If MyBase.GetTabRect(i).Contains(x, y) Then
				Return MyBase.TabPages(i)
			End If
		Next
		Return Nothing
	End Function

End Class
