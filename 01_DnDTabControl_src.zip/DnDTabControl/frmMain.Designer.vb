<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.tbcc = New DnDTabControl.TabControlDnD
		Me.TabPage1 = New System.Windows.Forms.TabPage
		Me.TabPage2 = New System.Windows.Forms.TabPage
		Me.TabPage3 = New System.Windows.Forms.TabPage
		Me.TabPage4 = New System.Windows.Forms.TabPage
		Me.tbcc.SuspendLayout()
		Me.SuspendLayout()
		'
		'tbcc
		'
		Me.tbcc.Controls.Add(Me.TabPage1)
		Me.tbcc.Controls.Add(Me.TabPage2)
		Me.tbcc.Controls.Add(Me.TabPage3)
		Me.tbcc.Controls.Add(Me.TabPage4)
		Me.tbcc.Cursor = System.Windows.Forms.Cursors.Default
		Me.tbcc.Dock = System.Windows.Forms.DockStyle.Fill
		Me.tbcc.Location = New System.Drawing.Point(0, 0)
		Me.tbcc.Name = "tbcc"
		Me.tbcc.SelectedIndex = 0
		Me.tbcc.Size = New System.Drawing.Size(292, 266)
		Me.tbcc.TabIndex = 0
		'
		'TabPage1
		'
		Me.TabPage1.Location = New System.Drawing.Point(4, 22)
		Me.TabPage1.Name = "TabPage1"
		Me.TabPage1.Size = New System.Drawing.Size(284, 240)
		Me.TabPage1.TabIndex = 0
		Me.TabPage1.Text = "TabPage1"
		Me.TabPage1.UseVisualStyleBackColor = True
		'
		'TabPage2
		'
		Me.TabPage2.Location = New System.Drawing.Point(4, 22)
		Me.TabPage2.Name = "TabPage2"
		Me.TabPage2.Size = New System.Drawing.Size(284, 240)
		Me.TabPage2.TabIndex = 1
		Me.TabPage2.Text = "TabPage2"
		Me.TabPage2.UseVisualStyleBackColor = True
		'
		'TabPage3
		'
		Me.TabPage3.Location = New System.Drawing.Point(4, 22)
		Me.TabPage3.Name = "TabPage3"
		Me.TabPage3.Size = New System.Drawing.Size(284, 240)
		Me.TabPage3.TabIndex = 2
		Me.TabPage3.Text = "TabPage3"
		Me.TabPage3.UseVisualStyleBackColor = True
		'
		'TabPage4
		'
		Me.TabPage4.Location = New System.Drawing.Point(4, 22)
		Me.TabPage4.Name = "TabPage4"
		Me.TabPage4.Size = New System.Drawing.Size(284, 240)
		Me.TabPage4.TabIndex = 3
		Me.TabPage4.Text = "TabPage4"
		Me.TabPage4.UseVisualStyleBackColor = True
		'
		'frmMain
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(292, 266)
		Me.Controls.Add(Me.tbcc)
		Me.Name = "frmMain"
		Me.Text = "frmMain"
		Me.tbcc.ResumeLayout(False)
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents tbcc As DnDTabControl.TabControlDnD
	Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
	Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
End Class
