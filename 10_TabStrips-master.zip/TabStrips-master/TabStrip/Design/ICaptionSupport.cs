namespace FarsiLibrary.Win.Design
{
    public interface ICaptionSupport
    {
        string Caption
        {
            get;
        }
    }
}
