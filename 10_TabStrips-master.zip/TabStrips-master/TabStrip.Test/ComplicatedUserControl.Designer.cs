namespace TabStrip.Test
{
    partial class ComplicatedUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Node19");
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Node0", new System.Windows.Forms.TreeNode[] {
            treeNode29});
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Node20");
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Node10", new System.Windows.Forms.TreeNode[] {
            treeNode31});
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Node1", new System.Windows.Forms.TreeNode[] {
            treeNode32});
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Node11");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Node2", new System.Windows.Forms.TreeNode[] {
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Node3");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Node24");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Node27");
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Node25", new System.Windows.Forms.TreeNode[] {
            treeNode38});
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Node26");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Node4", new System.Windows.Forms.TreeNode[] {
            treeNode37,
            treeNode39,
            treeNode40});
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Node12");
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("Node5", new System.Windows.Forms.TreeNode[] {
            treeNode42});
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Node17");
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Node16", new System.Windows.Forms.TreeNode[] {
            treeNode44});
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Node6", new System.Windows.Forms.TreeNode[] {
            treeNode45});
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Node18");
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("Node7", new System.Windows.Forms.TreeNode[] {
            treeNode47});
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Node15");
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("Node13", new System.Windows.Forms.TreeNode[] {
            treeNode49});
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("Node23");
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("Node14", new System.Windows.Forms.TreeNode[] {
            treeNode51});
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("Node22");
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("Node8", new System.Windows.Forms.TreeNode[] {
            treeNode50,
            treeNode52,
            treeNode53});
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("Node9");
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("Node21");
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.lblNodeName = new System.Windows.Forms.Label();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lblNodeName);
            this.splitContainer1.Size = new System.Drawing.Size(431, 226);
            this.splitContainer1.SplitterDistance = 143;
            this.splitContainer1.TabIndex = 0;
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            treeNode29.Name = "Node19";
            treeNode29.Text = "Node19";
            treeNode30.Name = "Node0";
            treeNode30.Text = "Node0";
            treeNode31.Name = "Node20";
            treeNode31.Text = "Node20";
            treeNode32.Name = "Node10";
            treeNode32.Text = "Node10";
            treeNode33.Name = "Node1";
            treeNode33.Text = "Node1";
            treeNode34.Name = "Node11";
            treeNode34.Text = "Node11";
            treeNode35.Name = "Node2";
            treeNode35.Text = "Node2";
            treeNode36.Name = "Node3";
            treeNode36.Text = "Node3";
            treeNode37.Name = "Node24";
            treeNode37.Text = "Node24";
            treeNode38.Name = "Node27";
            treeNode38.Text = "Node27";
            treeNode39.Name = "Node25";
            treeNode39.Text = "Node25";
            treeNode40.Name = "Node26";
            treeNode40.Text = "Node26";
            treeNode41.Name = "Node4";
            treeNode41.Text = "Node4";
            treeNode42.Name = "Node12";
            treeNode42.Text = "Node12";
            treeNode43.Name = "Node5";
            treeNode43.Text = "Node5";
            treeNode44.Name = "Node17";
            treeNode44.Text = "Node17";
            treeNode45.Name = "Node16";
            treeNode45.Text = "Node16";
            treeNode46.Name = "Node6";
            treeNode46.Text = "Node6";
            treeNode47.Name = "Node18";
            treeNode47.Text = "Node18";
            treeNode48.Name = "Node7";
            treeNode48.Text = "Node7";
            treeNode49.Name = "Node15";
            treeNode49.Text = "Node15";
            treeNode50.Name = "Node13";
            treeNode50.Text = "Node13";
            treeNode51.Name = "Node23";
            treeNode51.Text = "Node23";
            treeNode52.Name = "Node14";
            treeNode52.Text = "Node14";
            treeNode53.Name = "Node22";
            treeNode53.Text = "Node22";
            treeNode54.Name = "Node8";
            treeNode54.Text = "Node8";
            treeNode55.Name = "Node9";
            treeNode55.Text = "Node9";
            treeNode56.Name = "Node21";
            treeNode56.Text = "Node21";
            this.treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode30,
            treeNode33,
            treeNode35,
            treeNode36,
            treeNode41,
            treeNode43,
            treeNode46,
            treeNode48,
            treeNode54,
            treeNode55,
            treeNode56});
            this.treeView.Size = new System.Drawing.Size(143, 226);
            this.treeView.TabIndex = 0;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // lblNodeName
            // 
            this.lblNodeName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblNodeName.Location = new System.Drawing.Point(15, 11);
            this.lblNodeName.Name = "lblNodeName";
            this.lblNodeName.Size = new System.Drawing.Size(252, 39);
            this.lblNodeName.TabIndex = 0;
            // 
            // ComplicatedUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "ComplicatedUserControl";
            this.Size = new System.Drawing.Size(431, 226);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.Label lblNodeName;
    }
}
